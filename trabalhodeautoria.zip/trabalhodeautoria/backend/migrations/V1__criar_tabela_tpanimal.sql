create table tbTipoAnimal (
 	CoTipoAnimal int PRIMARY KEY AUTO_INCREMENT,
    NoTipoAnimal varchar(300) not null
);