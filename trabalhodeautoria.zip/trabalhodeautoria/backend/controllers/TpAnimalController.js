const express = require('express');
const router = express.Router();
const db = require('../util/db');
const verificarToken = require('../util/VerificaToken');

/**
 * Executa uma consulta no banco de dados e envia uma resposta.
 * @param {string} sql - A consulta SQL a ser executada.
 * @param {Array} params - Os parâmetros para a consulta SQL.
 * @param {Object} res - O objeto de resposta do Express.
 * @param {string} erroMsg - Mensagem de erro para ser enviada em caso de falha.
 */
function executarComandoSQL(sql, params, res, erroMsg) {
  db.query(sql, params, (err, result) => {
    if (err) {
      res.status(500).json({ erro: erroMsg, detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
}

// Rota para buscar todas as tarefas
router.get('/', (req, res) => {
  executarComandoSQL('SELECT * FROM tbTipoAnimal', [], res, "Erro na consulta de tarefas");
});

// Rota para buscar uma tbTipoAnimal específica
router.get("/:CoTipoAnimal", (req, res) => {
  const CoTipoAnimal = req.params.CoTipoAnimal;
  executarComandoSQL('SELECT * FROM tbTipoAnimal WHERE CoTipoAnimal = ?', [CoTipoAnimal], res, "Erro na consulta de tbTipoAnimal");
});

// Rota para criar uma nova tbTipoAnimal
router.post('/', (req, res) => {
  const { NoTipoAnimal } = req.body;
  executarComandoSQL('INSERT INTO tbTipoAnimal (NoTipoAnimal) VALUES (?)', [NoTipoAnimal], res, "Erro no cadastro de tbTipoAnimal!");
});

// Rota para deletar uma tbTipoAnimal
router.delete("/:CoTipoAnimal", (req, res) => {
  const CoTipoAnimal = req.params.CoTipoAnimal;
  executarComandoSQL('DELETE FROM tbTipoAnimal WHERE CoTipoAnimal = ?', [CoTipoAnimal], res, 'Erro ao deletar tbTipoAnimal');
});

// Rota para atualizar uma tbTipoAnimal
router.put('/', (req, res) => {
  const { CoTipoAnimal, NoTipoAnimal } = req.body;
  executarComandoSQL('UPDATE tbTipoAnimal SET NoTipoAnimal = ? WHERE CoTipoAnimal = ?', [NoTipoAnimal, CoTipoAnimal], res, "Erro ao atualizar tbTipoAnimal");
});

module.exports = router;