const express = require('express');
const router = express.Router();
const db = require('../util/db');
const verificarToken = require('../util/VerificaToken');

/**
 * Executa uma consulta no banco de dados e envia uma resposta.
 * @param {string} sql - A consulta SQL a ser executada.
 * @param {Array} params - Os parâmetros para a consulta SQL.
 * @param {Object} res - O objeto de resposta do Express.
 * @param {string} erroMsg - Mensagem de erro para ser enviada em caso de falha.
 */
function executarComandoSQL(sql, params, res, erroMsg) {
  db.query(sql, params, (err, result) => {
    if (err) {
      res.status(500).json({ erro: erroMsg, detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
}

// Rota para buscar todas os Servicos
router.get('/', (req, res) => {
  executarComandoSQL('SELECT * FROM tbServicos', [], res, "Erro na consulta os Servicos");
});

// Rota para buscar uma TbServicos específica
router.get("/:CoServicos", (req, res) => {
  const CoServicos = req.params.CoServicos;
  executarComandoSQL('SELECT * FROM tbServicos WHERE CoServicos = ?', [CoServicos], res, "Erro na consulta de TbServicos");
});

// Rota para criar uma nova TbServicos
router.post('/', (req, res) => {
  const { NoServicos, ValorServico } = req.body;
  const sql = 'INSERT INTO TbServicos (NoServicos, ValorServico) VALUES (?, ?)';

  db.query(sql, [NoServicos, ValorServico], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ erro: "Erro no cadastro de TbServicos!", detalhes: err });
    } else {
      res.status(200).json(result);
    }
  });
});


// Rota para deletar uma TbServicos
router.delete("/:CoServicos", (req, res) => {
  const CoServicos = req.params.CoServicos;
  executarComandoSQL('DELETE FROM TbServicos WHERE CoServicos = ?', [CoServicos], res, 'Erro ao deletar TbServicos');
});

// Rota para atualizar uma TbServicos
router.put('/', (req, res) => {
  const { CoServicos, NoServicos, ValorServico } = req.body;
  executarComandoSQL('UPDATE TbServicos SET NoServicos = ?, ValorServico = ? WHERE CoServicos = ?', [ NoServicos, ValorServico, CoServicos], res, "Erro ao atualizar TbServicos");
});


module.exports = router;