/**
 * Renderiza o formulário para criar um novo tbservico.
 * @return {string} HTML do formulário de criação de tbservico.
 */
function renderizarFormulario() {
  return `
          <form class="mt-3" id="formulario_servico">
              <div class="form-group">
                  <label for="servico_nome">Nome:</label>
                  <input type="text" class="form-control" id="servico_nome_formulario">
              </div>
              <div class="form-group">
                  <label for="servico_valor">Valor:</label>
                  <textarea class="form-control" id="servico_valor_formulario"></textarea>
              </div>
              <button type="submit" class="btn btn-primary mt-2">Salvar</button>
          </form>
      `;
}

/**
 * Renderiza o formulário para atualizar um tbservico existente.
 * @param {Object} tbservicos - O tbservicos a ser atualizado.
 * @return {string} HTML do formulário de atualização de tbservicos.
 */
function renderizarFormularioAtualizar(tbservicos) {
    return `
            <form class="mt-3" id="formulario_servico_atualizar">
                <input type="hidden" class="form-control" id="servico_id_formulario" value="${tbservicos.CoServicos}">
                <div class="form-group">
                    <label for="servico_nome">Nome do servico:</label>
                    <input type="text" class="form-control" id="servico_nome_formulario" value="${tbservicos.NoServicos}">
                </div>
                <div class="form-group">
                    <label for="servico_valor">Valor:</label>
                    <textarea class="form-control" id="servico_valor_formulario">${tbservicos.ValorServico}</textarea>
                </div>
                <button type="submit" class="btn btn-primary mt-2">Salvar</button>
            </form>
        `;
}

  /**
 * Renderiza a tabela de tbservico.
 * @param {Array} tbservicos - Lista de tbservico a serem exibidas.
 * @return {string} HTML da tabela de tbservico.
 */
function renderizarTabela(tbservicos) {
  let tabela = `
          <table class="table table-striped mt-3">
              <thead>
                  <tr>
                      <th>Serviço</th>
                      <th>Valor</th>
                      <th>Ações</th>
                  </tr>
              </thead>
              <tbody>
      `;

  tbservicos.forEach((tbservicos) => {
    tabela += `
              <tr>
                  <td>${tbservicos.NoServicos}</td>
                  <td>${tbservicos.ValorServico}</td>
                  <td>
                    <button class="excluir-btn" servico-id=${tbservicos.CoServicos}>Excluir</button>
                    <button class="atualizar-btn" servico-atualizar-id=${tbservicos.CoServicos}>Atualizar</button>
                  </td>
              </tr>
          `;
  });

  tabela += `
              </tbody>
          </table>
      `;

  return tabela;
}

const ServicoView = {
    renderizarFormulario,
    renderizarTabela,
    renderizarFormularioAtualizar
};

export default ServicoView;
