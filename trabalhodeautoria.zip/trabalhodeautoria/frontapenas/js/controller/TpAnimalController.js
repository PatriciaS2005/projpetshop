import AnimalView from "../view/AnimalView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de Servico.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarTpAnimalFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = AnimalView.renderizarFormulario();
  document.getElementById("formulario_tpanimal").addEventListener("submit", cadastrarTpAnimal);
}

/**
 * Cadastra um novo Servico.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarTpAnimal(event) {
  event.preventDefault();
  const nomeValor = document.getElementById("tpanimal_nome_formulario").value;
  const novaTpAnimal = { NoTipoAnimal: nomeValor };

  try {
    await fetch(`${API_BASE_URL}/tpanimal`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaTpAnimal),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaTpAnimal(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar TpAnimal:", error);
  }
}
/**
 * Renderiza a lista de tipo de animais.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaTpAnimal(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/tpanimal");
    const tbtipoanimalBD = await response.json(); 

    const tbtipoanimal = tbtipoanimalBD.map((row) => {
      return {
        CoTipoAnimal: row.CoTipoAnimal,
        NoTipoAnimal: row.NoTipoAnimal,
      };
    });
    componentePrincipal.innerHTML = AnimalView.renderizarTabela(tbtipoanimal);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar tpanimal:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de Servico.
 * Cada botão, quando clicado, aciona a função de exclusão de Servico correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const TpAnimalId = this.getAttribute("tpanimal-id");
      excluirTpAnimal(TpAnimalId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de Servico.
 * Cada botão, quando clicado, aciona a função de buscar a Servico específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const TpAnimalId = this.getAttribute("tpanimal-atualizar-id");
      buscarTpAnimal(TpAnimalId);
    });
  });
}

/**
 * Exclui um Servico específico com base no ID.
 * Após a exclusão bem-sucedida, a lista de Servicos é atualizada.
 * @param {string} CoTipoAnimal - ID da Servico a ser excluída.
 */
async function excluirTpAnimal(CoTipoAnimal) {
  try {
    const response = await fetch(`${API_BASE_URL}/tpanimal/${CoTipoAnimal}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a Servico");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaTpAnimal(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a Servico:", error);
  }
}

/**
 * Busca uma Servico específica para atualização, com base no ID.
 * Após encontrar a Servico, renderiza o formulário de atualização.
 * @param {string} CoServico - ID da Servico a ser buscada.
 */
async function buscarTpAnimal(CoTipoAnimal) {
  try {
    const response = await fetch(`${API_BASE_URL}/tpanimal/${CoTipoAnimal}`);
    const tbtipoanimalBD = await response.json();
    if (tbtipoanimalBD.length <= 0) return;

    const tbtipoanimal = tbtipoanimalBD.map(row => ({
      CoTipoAnimal: row.CoTipoAnimal,
      NoTipoAnimal: row.NoTipoAnimal,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = AnimalView.renderizarFormularioAtualizar(tbtipoanimal); 
    document.getElementById("formulario_tpanimal_atualizar").addEventListener("submit", atualizarTpAnimal);
  } catch (error) {
    console.error("Erro ao buscar Servicos:", error);
  }
}

/**
 * Atualiza uma Servico específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarTpAnimal(event) {
  event.preventDefault();

  const idValor = document.getElementById("tpanimal_id_formulario").value;
  const nomeValor = document.getElementById("tpanimal_nome_formulario").value;
  const tbtipoanimal = {CoTipoAnimal: idValor, NoTipoAnimal: nomeValor};

  try {
    const response = await fetch(`${API_BASE_URL}/tpanimal`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(tbtipoanimal),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a Servico");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaTpAnimal(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar Servico. Status:", response.status, "Mensagem:", error.message);

  }
}

const TpAnimalController = {
  renderizarTpAnimalFormulario,
  cadastrarTpAnimal,
  renderizarListaTpAnimal,
  excluirTpAnimal,
};

export default TpAnimalController;
