import ServicoView from "../view/ServicoView.js";
import { API_BASE_URL } from "../config/config.js";

/**
 * Renderiza o formulário de Servico.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde o formulário será renderizado.
 */
function renderizarServicoFormulario(componentePrincipal) {
  componentePrincipal.innerHTML = ServicoView.renderizarFormulario();
  document.getElementById("formulario_servico").addEventListener("submit", cadastrarServico);
}

/**
 * Cadastra um novo Servico.
 * @param {Event} event - Evento do formulário.
 */
async function cadastrarServico(event) {
  event.preventDefault();
  const nomeValor = document.getElementById("servico_nome_formulario").value;
  const ValValor = document.getElementById("servico_valor_formulario").value;
  const novaServico = { NoServicos: nomeValor, ValorServico: ValValor };

  try {
    await fetch(`${API_BASE_URL}/servico`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(novaServico),
    });
    const componentePrincipal = document.querySelector("#conteudo_principal");
    await renderizarListaServicos(componentePrincipal);
  } catch (error) {
    console.error("Erro ao adicionar Servico:", error);
  }
}
/**
 * Renderiza a lista de Servicos.
 * @param {HTMLElement} componentePrincipal - Elemento principal onde a lista será renderizada.
 */
async function renderizarListaServicos(componentePrincipal) {
  try {
    const response = await fetch(API_BASE_URL + "/servico");
    const tbservicosBD = await response.json(); 

    const tbservicos = tbservicosBD.map((row) => {
      return {
        CoServicos: row.CoServicos,
        NoServicos: row.NoServicos,
        ValorServico: row.ValorServico,
      };
    });
    componentePrincipal.innerHTML = ServicoView.renderizarTabela(tbservicos);
    inserirEventosExcluir();
    inserirEventosAtualizar();
  } catch (error) {
    console.error("Erro ao buscar Servicos:", error);
  }
}

/**
 * Adiciona eventos de clique aos botões de exclusão de Servico.
 * Cada botão, quando clicado, aciona a função de exclusão de Servico correspondente.
 */
function inserirEventosExcluir() {
  const botoesExcluir = document.querySelectorAll(".excluir-btn");
  botoesExcluir.forEach((botao) => {
    botao.addEventListener("click", function () {
      const ServicoId = this.getAttribute("servico-id");
      excluirServico(ServicoId);
    });
  });
}

/**
 * Adiciona eventos de clique aos botões de atualização de Servico.
 * Cada botão, quando clicado, aciona a função de buscar a Servico específica para atualização.
 */
function inserirEventosAtualizar() {
  const botoesAtualizar = document.querySelectorAll(".atualizar-btn");
  botoesAtualizar.forEach((botao) => {
    botao.addEventListener("click", function () {
      const ServicoId = this.getAttribute("servico-atualizar-id");
      buscarServico(ServicoId);
    });
  });
}

/**
 * Exclui um Servico específico com base no ID.
 * Após a exclusão bem-sucedida, a lista de Servicos é atualizada.
 * @param {string} CoServicos - ID da Servico a ser excluída.
 */
async function excluirServico(CoServicos) {
  try {
    const response = await fetch(`${API_BASE_URL}/servico/${CoServicos}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Erro ao excluir a Servico");
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaServicos(componentePrincipal);
  } catch (error) {
    console.error("Erro ao excluir a Servico:", error);
  }
}

/**
 * Busca uma Servico específica para atualização, com base no ID.
 * Após encontrar a Servico, renderiza o formulário de atualização.
 * @param {string} CoServicos - ID da Servico a ser buscada.
 */
async function buscarServico(CoServicos) {
  try {
    const response = await fetch(`${API_BASE_URL}/servico/${CoServicos}`);
    const tbservicosBD = await response.json();
    if (tbservicosBD.length <= 0) return;

    const tbservicos = tbservicosBD.map(row => ({
      CoServicos: row.CoServicos,
      NoServicos: row.NoServicos,
      ValorServico: row.ValorServico,
    }))[0];

    const componentePrincipal = document.querySelector("#conteudo_principal");
    componentePrincipal.innerHTML = ServicoView.renderizarFormularioAtualizar(tbservicos); 
    document.getElementById("formulario_servico_atualizar").addEventListener("submit", atualizarServico);
  } catch (error) {
    console.error("Erro ao buscar Servicos:", error);
  }
}

/**
 * Atualiza uma Servico específica.
 * A função é acionada pelo evento de submit do formulário de atualização.
 * @param {Event} event - O evento de submit do formulário.
 */
async function atualizarServico(event) {
  event.preventDefault();

  const idValor = document.getElementById("servico_id_formulario").value;
  const nomeValor = document.getElementById("servico_nome_formulario").value;
  const ValValor = document.getElementById("servico_valor_formulario").value;
  const tbservicos = {CoServicos: idValor, NoServicos: nomeValor, ValorServico: ValValor,};

  try {
    const response = await fetch(`${API_BASE_URL}/servico`, {
      method: "PUT",
      headers: {"Content-Type": "application/json",},
      body: JSON.stringify(tbservicos),
    });

    if (!response.ok) {
      throw new Error("Falha ao atualizar a Servico");
    }
    const componentePrincipal = document.querySelector("#conteudo_principal");
    renderizarListaServicos(componentePrincipal);
  } catch (error) {
    console.error("Erro ao atualizar Servico. Status:", response.status, "Mensagem:", error.message);

  }
}

const ServicoController = {
  renderizarServicoFormulario,
  cadastrarServico,
  renderizarListaServicos,
  excluirServico,
};

export default ServicoController;
